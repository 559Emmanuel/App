from flask import Flask
import mysql.connector

app = Flask(__name__)

def get_db_connection():
    connection = mysql.connector.connect(
        host="db",
        user="root",
        password="rootpassword",  # Asegúrate de usar la contraseña correcta
        database="db_schedule"
    )
    return connection

@app.route('/')
def index():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM your_table')
    results = cursor.fetchall()
    cursor.close()
    connection.close()
    return str(results)

if __name__ == '__main__':
    app.run(host='0.0.0.0')
