const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.post('/join', (req, res) => {
  const { session_id, student_name } = req.body;
  const query = 'INSERT INTO Session_students (Session_id, student_name) VALUES (?, ?)';
  db.query(query, [session_id, student_name], (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send('Student joined session successfully');
  });
});

module.exports = router;
