const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.post('/register', (req, res) => {
  const { subject, session_date, session_time, teacher_id } = req.body;
  const query = 'INSERT INTO Advisory_sessions (subject, session_date, session_time, Teacher_id) VALUES (?, ?, ?, ?)';
  db.query(query, [subject, session_date, session_time, teacher_id], (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send('Session registered successfully');
  });
});

module.exports = router;
