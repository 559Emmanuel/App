const waitPort = require('wait-port');
const mysql = require('mysql');
const express = require('express');
const app = express();
const port = 3000;

const dbConfig = {
  host: process.env.DB_HOST || 'db',
  user: process.env.DB_USER || 'user',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'mydatabase'
};

const waitForDatabase = async () => {
  const isOpen = await waitPort({
    host: dbConfig.host,
    port: 3306,
    timeout: 30000 // Esperar hasta 30 segundos
  });

  if (isOpen) {
    const connection = mysql.createConnection(dbConfig);
    connection.connect(err => {
      if (err) {
        console.error('Error connecting to the database:', err);
        process.exit(1);
      } else {
        console.log('Connected to the database');
        startServer();
      }
    });
  } else {
    console.error('Database did not start in time');
    process.exit(1);
  }
};

const startServer = () => {
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
};

waitForDatabase();
