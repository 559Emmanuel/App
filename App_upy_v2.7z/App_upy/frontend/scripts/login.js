document.getElementById('authForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const use_name = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch('http://localhost:3000/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ use_name, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const user = data.user;
            if (user.role === 'advisor') {
                window.location.href = 'asesor_options.html';
            } else if (user.role === 'advisee') {
                window.location.href = 'alumnos.html';
            }
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('There was an error submitting the form');
    });
});
