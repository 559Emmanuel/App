document.addEventListener('DOMContentLoaded', function() {
    let particleContainer = document.getElementById('particle-container');

    function createParticle() {
        let particle = document.createElement('div');
        particle.classList.add('particle');
        particle.style.left = Math.random() * 100 + 'vw';
        particle.style.width = Math.random() * 10 + 'px';
        particle.style.height = particle.style.width;
        particleContainer.appendChild(particle);

        setTimeout(() => {
            particle.remove();
        }, 10000); // Duración de la animación
    }

    setInterval(createParticle, 300);

    const data = {
        "advisees": [
            {
                "name": "Alice Johnson",
                "subject": "Mathematics",
                "semester": "First"
            },
            {
                "name": "Bob Smith",
                "subject": "Mathematics",
                "semester": "Second"
            },
            {
                "name": "Charlie Brown",
                "subject": "Mathematics",
                "semester": "Third"
            }
        ]
    };

    const adviseesContainer = document.getElementById('adviseesContainer');
    data.advisees.forEach(advisee => {
        const adviseeElement = document.createElement('div');
        adviseeElement.classList.add('advisee');
        adviseeElement.innerHTML = `
            <p><strong>Name:</strong> ${advisee.name}</p>
            <p><strong>Subject:</strong> ${advisee.subject}</p>
            <p><strong>Semester:</strong> ${advisee.semester}</p>
        `;
        adviseesContainer.appendChild(adviseeElement);
    });

    document.getElementById('logoutBtn').addEventListener('click', function() {
        window.location.href = 'login.html';
    });
});
