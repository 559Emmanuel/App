const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 5000;

app.use(bodyParser.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'university_schedule'
});

db.connect(err => {
    if (err) {
        throw err;
    }
    console.log('MySQL connected...');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            res.json({ error: err });
        } else if (results.length > 0) {
            res.json({ message: 'Login successful' });
        } else {
            res.json({ error: 'Invalid username or password' });
        }
    });
});

app.post('/register', (req, res) => {
    const { username, password, userType } = req.body;
    const query = 'INSERT INTO users (username, password, userType) VALUES (?, ?, ?)';
    db.query(query, [username, password, userType], (err, results) => {
        if (err) {
            res.json({ error: err });
        } else {
            res.json({ message: 'Registration successful' });
        }
    });
});

app.post('/submit_availability', (req, res) => {
    const { tutorName, subject, availableTimes } = req.body;
    const query = 'INSERT INTO availability (tutorName, subject, availableTimes) VALUES (?, ?, ?)';
    db.query(query, [tutorName, subject, availableTimes], (err, results) => {
        if (err) {
            res.json({ error: err });
        } else {
            res.json({ message: 'Availability submitted' });
        }
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
