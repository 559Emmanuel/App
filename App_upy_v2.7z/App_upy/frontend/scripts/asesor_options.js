document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('registerSessionBtn').addEventListener('click', function () {
        // Redirigir a asesoria_registro.html
        window.location.href = 'asesoria_registro.html';
    });

    document.getElementById('viewSessionsBtn').addEventListener('click', function () {
        // Redirigir a asesor.html
        window.location.href = 'asesor.html';
    });
});
