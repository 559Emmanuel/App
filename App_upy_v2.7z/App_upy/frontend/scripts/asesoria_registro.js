document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const teacher_id = 1; // Deberás obtener el ID del asesor autenticado
    const subject = document.getElementById('sessionSubject').value;
    const session_date = document.getElementById('sessionDate').value;
    const session_time = document.getElementById('sessionTime').value;

    fetch('http://localhost:3000/sessions/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ teacher_id, subject, session_date, session_time })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('New advisory session registered successfully!');
            window.location.href = 'asesor.html';
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('There was an error registering the session');
    });
});
