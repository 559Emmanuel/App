document.addEventListener('DOMContentLoaded', function() {
    fetch('http://localhost:3000/sessions')
        .then(response => response.json())
        .then(data => {
            const sessionsContainer = document.getElementById('sessionsContainer');
            data.sessions.forEach(session => {
                const sessionElement = document.createElement('div');
                sessionElement.classList.add('session');
                sessionElement.innerHTML = `
                    <p><strong>Time:</strong> ${session.session_time}</p>
                    <p><strong>Subject:</strong> ${session.subject}</p>
                    <p><strong>Teacher:</strong> ${session.Teacher_id}</p>
                    <button class="join-btn" data-session-id="${session.Session_id}">Join Session</button>
                `;
                sessionsContainer.appendChild(sessionElement);
            });

            document.querySelectorAll('.join-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const studentName = prompt('Enter your name:');
                    if (studentName) {
                        const session_id = this.getAttribute('data-session-id');
                        fetch('http://localhost:3000/students/join', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ session_id, student_name: studentName })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert(`${studentName} has joined the session successfully!`);
                                this.parentElement.remove(); // Eliminar la sesión de la lista después de unirse
                            } else {
                                alert('Error joining the session.');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('There was an error joining the session.');
                        });
                    }
                });
            });
        })
        .catch(error => console.error('Error loading sessions:', error));

    document.getElementById('logoutBtn').addEventListener('click', function() {
        window.location.href = 'login.html';
    });
});
